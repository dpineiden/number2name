# number2name
Pequeño programa que permite obtener el nombre de un numero de 0 a 999.999.999.999 en castellano, hecho en python
